#!/usr/bin/env bash
# Testa o quiz SEM o Pitiupi (a ponte "plugin/" fica de fora).
# Uso (dentro de plugins/musicquiz):  standalone/build.sh test | demo [pasta-de-musicas]
set -e
cd "$(dirname "$0")/.."
rm -rf /tmp/musicquiz-out && mkdir -p /tmp/musicquiz-out
javac -encoding UTF-8 -d /tmp/musicquiz-out \
  $(find src -name '*.java' -not -path '*/plugin/*') $(find standalone -name '*.java')
case "$1" in
  test) java -cp /tmp/musicquiz-out pitiupi.musicquiz.EngineTest && java -Djava.awt.headless=true -cp /tmp/musicquiz-out pitiupi.musicquiz.IntegrationTest ;;
  demo) java -cp /tmp/musicquiz-out pitiupi.musicquiz.Demo "${2:-demo-songs}" ;;
  *) echo "uso: standalone/build.sh test|demo" ;;
esac
