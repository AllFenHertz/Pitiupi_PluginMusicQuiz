package pitiupi.musicquiz;

import java.io.File;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/** Abre 1 host e 2 jogadores na mesma JVM, ligados por Loopback. */
public class Demo {
    public static void main(String[] args) throws Exception {
        File dir = new File(args.length > 0 ? args[0] : "demo-songs");
        if (!new File(dir, "songs.tsv").exists()) SampleSongs.generate(dir);
        Loopback net = new Loopback();
        SwingUtilities.invokeLater(() -> {
            frame("Host (não joga)", new HostPanel(net.transport("Host"), dir), 20, 20);
            frame("Jogador: Ana", new PlayerPanel(net.transport("Ana"), dir), 700, 20);
            frame("Jogador: Bia", new PlayerPanel(net.transport("Bia"), dir), 700, 420);
        });
    }

    private static void frame(String title, JPanel p, int x, int y) {
        JFrame f = new JFrame(title);
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        f.setContentPane(p);
        f.pack();
        f.setLocation(x, y);
        f.setVisible(true);
    }
}
