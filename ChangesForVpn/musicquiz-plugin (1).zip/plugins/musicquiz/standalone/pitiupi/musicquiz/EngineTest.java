package pitiupi.musicquiz;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class EngineTest {
    static int failures = 0;

    static void check(boolean cond, String msg) {
        if (!cond) { failures++; System.out.println("FALHOU: " + msg); }
        else System.out.println("ok: " + msg);
    }

    public static void main(String[] args) {
        // comparador
        check(AnswerMatcher.matches("  DÓ!! ", List.of("Dó")), "normaliza acento/caixa/pontuação");
        check(AnswerMatcher.matches("Bohemian Rapsody", List.of("Bohemian Rhapsody")), "tolera 1 erro em título longo");
        check(!AnswerMatcher.matches("mi", List.of("re")), "rejeita resposta errada");
        check(!AnswerMatcher.matches("", List.of("re")), "rejeita vazio");

        // motor
        AtomicLong now = new AtomicLong(1000);
        List<QuizPacket> out = new ArrayList<>();
        HostEngine e = new HostEngine("Host", now::get, out::add);
        List<Song> songs = List.of(
            new Song(new File("01.wav"), List.of("Alfa", "a")),
            new Song(new File("02.wav"), List.of("Beta")));
        e.configure(songs, 10_000, 2);

        check(e.start() != null, "não inicia sem jogadores");
        e.join("Ana");
        check(e.start() != null, "não inicia com 1 jogador (mín. 2)");
        e.join("Bia");
        e.join("Host");
        check(e.playerCount() == 2, "host não entra como jogador");

        check(e.start() == null, "inicia com 2 jogadores");
        QuizPacket last = out.get(out.size() - 1);
        check(last.phase == QuizPacket.Phase.ROUND && last.round == 0, "rodada 0 em andamento");
        check(last.correctAnswer == null, "resposta correta NÃO vaza durante a rodada");

        e.onAnswer("Ana", 0, "alfa", true);
        check(e.phase() == QuizPacket.Phase.ROUND, "um ok só não encerra");
        e.onAnswer("Ana", 0, "outra", true);          // já travada, ignorada
        e.onAnswer("Bia", 5, "alfa", true);           // rodada errada, ignorada
        check(e.phase() == QuizPacket.Phase.ROUND, "respostas inválidas são ignoradas");
        e.onAnswer("Bia", 0, "gama", true);
        last = out.get(out.size() - 1);
        check(last.phase == QuizPacket.Phase.REVEAL, "todos ok -> reveal");
        check("Alfa".equals(last.correctAnswer), "reveal mostra a resposta");
        check(last.scores.get("Ana") == 1 && last.scores.get("Bia") == 0, "pontuação certa");
        check(Boolean.TRUE.equals(last.correct.get("Ana")) && Boolean.FALSE.equals(last.correct.get("Bia")), "marcação certo/errado");

        e.next();
        check(e.phase() == QuizPacket.Phase.ROUND, "próxima rodada");
        now.addAndGet(10_001);
        e.tick();
        check(e.phase() == QuizPacket.Phase.REVEAL, "tempo esgotado -> reveal");
        last = out.get(out.size() - 1);
        check(last.answers.get("Ana").isEmpty(), "sem resposta fica vazio");

        e.next();
        last = out.get(out.size() - 1);
        check(last.phase == QuizPacket.Phase.END, "acabaram as músicas -> END");

        // saída no meio da rodada
        e.backToLobby();
        e.configure(songs, 10_000, 2);
        e.start();
        e.onAnswer("Ana", 0, "alfa", true);
        e.leave("Bia");
        check(e.phase() == QuizPacket.Phase.REVEAL, "quem sai não trava a rodada");

        // heartbeat reenvia o estado atual
        int before = out.size();
        e.heartbeat();
        check(out.size() == before + 1 && out.get(out.size() - 1).phase == QuizPacket.Phase.REVEAL,
              "heartbeat reenvia o estado atual");

        // ---- preparação: envio dos áudios aos jogadores ----
        AtomicLong t2 = new AtomicLong(5000);
        List<QuizPacket> out2 = new ArrayList<>();
        HostEngine p2 = new HostEngine("Host", t2::get, out2::add);
        List<List<Song>> hooks = new ArrayList<>();
        p2.setPrepare(true);
        p2.setPrepareHook(hooks::add);
        p2.configure(songs, 10_000, 2);
        p2.join("Ana");
        p2.join("Bia");
        check(p2.start() == null && p2.phase() == QuizPacket.Phase.PREPARING, "com envio de áudio, começa em PREPARING");
        check(hooks.size() == 1 && hooks.get(0).size() == 2, "dispara o envio das músicas sorteadas");
        long gid = p2.gameId();
        p2.onAudioStatus("Ana", gid, List.of("01.wav"));
        check(p2.phase() == QuizPacket.Phase.PREPARING, "arquivos incompletos não liberam");
        p2.onAudioStatus("Ana", gid, List.of("01.wav", "02.wav"));
        p2.onAudioStatus("Bia", gid + 1, List.of("01.wav", "02.wav"));
        check(p2.phase() == QuizPacket.Phase.PREPARING, "status de outra partida é ignorado");
        QuizPacket prep = out2.get(out2.size() - 1);
        check(prep.phase == QuizPacket.Phase.PREPARING && prep.readyPlayers.equals(List.of("Ana")), "estado informa quem já está pronto");
        p2.onAudioStatus("Bia", gid, List.of("01.wav", "02.wav"));
        check(p2.phase() == QuizPacket.Phase.ROUND, "todos prontos -> primeira rodada");

        p2.backToLobby();
        p2.configure(songs, 10_000, 2);
        p2.start();
        t2.addAndGet(HostEngine.PREP_TIMEOUT_MS + 1);
        p2.tick();
        check(p2.phase() == QuizPacket.Phase.ROUND, "limite de espera esgotado -> começa mesmo assim");

        p2.backToLobby();
        p2.configure(songs, 10_000, 2);
        p2.start();
        p2.skipPreparation();
        check(p2.phase() == QuizPacket.Phase.ROUND, "host pode começar sem esperar");

        p2.backToLobby();
        p2.configure(songs, 10_000, 2);
        p2.start();
        p2.onAudioStatus("Ana", p2.gameId(), List.of("01.wav", "02.wav"));
        p2.leave("Bia");
        check(p2.phase() == QuizPacket.Phase.ROUND, "quem sai durante a preparação não trava o início");

        // ---- áudio em pedaços ----
        try {
            byte[] original = new byte[300_000];
            new java.util.Random(42).nextBytes(original);
            File tmp = File.createTempFile("quiz", ".wav");
            tmp.deleteOnExit();
            java.nio.file.Files.write(tmp.toPath(), original);

            List<QuizPacket> sent = new ArrayList<>();
            boolean ok = AudioSender.sendClip(tmp, 7L, "Host", "Ana", p -> sent.add(p));
            check(ok && sent.size() == 3, "arquivo de 300 KB sai em 3 pedaços");
            check(!AudioSender.sendClip(tmp, 7L, "Host", "Ana", p -> false), "envio que sempre falha devolve false");

            AudioStore store = new AudioStore();
            java.util.Collections.shuffle(sent, new java.util.Random(1));
            boolean completed = false;
            store.accept(sent.get(0));
            store.accept(sent.get(0));    // repetido
            for (int i = 1; i < sent.size(); i++) completed = store.accept(sent.get(i));
            check(completed && store.has(tmp.getName()), "remonta o arquivo com pedaços fora de ordem e repetidos");
            check(java.util.Arrays.equals(original, java.nio.file.Files.readAllBytes(store.file(tmp.getName()).toPath())),
                  "arquivo remontado é idêntico ao original");

            QuizPacket stale = new QuizPacket(QuizPacket.Kind.AUDIO, "Host");
            stale.gameId = 3L; stale.clip = "x.wav"; stale.chunkTotal = 1; stale.data = new byte[1];
            check(!store.accept(stale), "pedaço de partida antiga é ignorado");
            QuizPacket evil = new QuizPacket(QuizPacket.Kind.AUDIO, "Host");
            evil.gameId = 7L; evil.clip = "../fora.wav"; evil.chunkTotal = 1; evil.data = new byte[1];
            check(!store.accept(evil), "nome de arquivo com caminho é recusado");
            store.advanceTo(8L);
            check(!store.has(tmp.getName()), "partida nova descarta os arquivos da anterior");
            store.clear();
        } catch (Exception ex) {
            failures++;
            System.out.println("FALHOU (exceção no teste de áudio): " + ex);
        }

        System.out.println(failures == 0 ? "\nTODOS OS TESTES PASSARAM" : "\nFALHAS: " + failures);
        System.exit(failures == 0 ? 0 : 1);
    }
}
