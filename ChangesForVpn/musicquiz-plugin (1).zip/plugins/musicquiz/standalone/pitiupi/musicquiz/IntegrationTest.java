package pitiupi.musicquiz;

import java.io.File;
import java.lang.reflect.Field;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Partida completa SEM janelas visíveis (modo headless): um host e dois jogadores ligados por Loopback,
 * com envio real dos áudios em pedaços. Confere do JOIN até o placar final.
 */
public class IntegrationTest {
    static int failures = 0;

    static void check(boolean cond, String msg) {
        if (!cond) { failures++; System.out.println("FALHOU: " + msg); }
        else System.out.println("ok: " + msg);
    }

    @SuppressWarnings("unchecked")
    static <T> T field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return (T) f.get(o);
    }

    static void ui(Runnable r) throws Exception { SwingUtilities.invokeAndWait(r); }

    static boolean waitFor(java.util.function.BooleanSupplier c, long ms) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (c.getAsBoolean()) return true;
            Thread.sleep(50);
        }
        return c.getAsBoolean();
    }

    static String text(Object panel, String f) throws Exception {
        JTextArea a = field(panel, f);
        String[] out = new String[1];
        ui(() -> out[0] = a.getText());
        return out[0];
    }

    public static void main(String[] args) throws Exception {
        System.setProperty("java.awt.headless", "true");
        File dir = new File(System.getProperty("java.io.tmpdir"), "quiz-it-" + System.nanoTime());
        SampleSongs.generate(dir);

        Loopback net = new Loopback();
        HostPanel[] host = new HostPanel[1];
        PlayerPanel[] ana = new PlayerPanel[1];
        PlayerPanel[] bia = new PlayerPanel[1];
        ui(() -> {
            host[0] = new HostPanel(net.transport("Host"), dir);
            ana[0] = new PlayerPanel(net.transport("Ana"), null);
            bia[0] = new PlayerPanel(net.transport("Bia"), null);
        });

        JButton joinA = field(ana[0], "joinBtn"), joinB = field(bia[0], "joinBtn");
        ui(() -> { joinA.doClick(); joinB.doClick(); });
        check(waitFor(() -> { try { return text(host[0], "log").contains("Ana, Bia"); } catch (Exception e) { return false; } }, 5000),
              "host vê os dois jogadores na sala");

        // 2 rodadas, 5 segundos
        javax.swing.JSpinner rounds = field(host[0], "rounds");
        ui(() -> rounds.setValue(2));
        JButton start = field(host[0], "startBtn");
        ui(start::doClick);

        check(waitFor(() -> { try { return text(ana[0], "info").contains("Rodada 1/2"); } catch (Exception e) { return false; } }, 15000),
              "áudios enviados e primeira rodada começa para a Ana");
        check(waitFor(() -> { try { return text(bia[0], "info").contains("Rodada 1/2"); } catch (Exception e) { return false; } }, 5000),
              "e para a Bia");

        AudioStore sa = field(ana[0], "store");
        AudioStore sb = field(bia[0], "store");
        check(sa.doneClips().size() == 2 && sb.doneClips().size() == 2, "cada jogador recebeu os 2 arquivos sorteados");

        // responde certo e errado, nas duas rodadas
        for (int r = 0; r < 2; r++) {
            final int round = r;
            // a resposta certa da rodada r: descobre pelo clip sorteado no host
            java.util.List<Song> songs = field(field(host[0], "engine"), "songs");
            String certa = songs.get(round).title;
            JTextField fa = field(ana[0], "answer"), fb = field(bia[0], "answer");
            JButton oa = field(ana[0], "okBtn"), ob = field(bia[0], "okBtn");
            check(waitFor(() -> oa.isEnabled() && ob.isEnabled(), 5000), "rodada " + (r + 1) + ": jogadores podem responder");
            ui(() -> { fa.setText(certa); oa.doClick(); fb.setText("resposta errada"); ob.doClick(); });
            check(waitFor(() -> { try { return text(ana[0], "info").contains("resposta: " + certa); } catch (Exception e) { return false; } }, 5000),
                  "rodada " + (r + 1) + ": todos deram OK -> reveal na hora");
            if (r == 0) {
                JButton next = field(host[0], "nextBtn");
                ui(next::doClick);
            }
        }
        JButton next = field(host[0], "nextBtn");
        ui(next::doClick);
        check(waitFor(() -> { try { return text(ana[0], "info").contains("Fim de jogo"); } catch (Exception e) { return false; } }, 5000),
              "fim de jogo com placar");
        String fim = text(ana[0], "info");
        check(fim.contains("1. Ana — 2") && fim.contains("2. Bia — 0"), "placar final: Ana 2, Bia 0");

        ui(() -> { host[0].dispose(); ana[0].dispose(); bia[0].dispose(); });
        System.out.println(failures == 0 ? "\nINTEGRAÇÃO OK" : "\nFALHAS: " + failures);
        System.exit(failures == 0 ? 0 : 1);
    }
}
