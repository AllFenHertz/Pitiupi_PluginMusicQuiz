package pitiupi.musicquiz;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** "Rede" em memória para testar tudo em uma única JVM, sem o Pitiupi. */
public class Loopback {
    private final List<Consumer<QuizPacket>> listeners = new CopyOnWriteArrayList<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "quiz-loopback");
        t.setDaemon(true);
        return t;
    });

    public QuizTransport transport(String name) {
        return new QuizTransport() {
            public String selfName() { return name; }
            public void send(QuizPacket p) {
                exec.execute(() -> { for (Consumer<QuizPacket> l : listeners) l.accept(p); });
            }
            public void sendToHost(QuizPacket p) { send(p); }
            public boolean sendToPlayer(QuizPacket p, String ip) { send(p); return true; }
            public void setListener(Consumer<QuizPacket> l) { listeners.add(l); }
        };
    }
}
