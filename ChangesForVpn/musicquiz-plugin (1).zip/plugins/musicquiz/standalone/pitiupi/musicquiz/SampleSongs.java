package pitiupi.musicquiz;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

/** Gera um pacote de teste: tons de piano de brinquedo (do, re, mi, fa) em WAV. */
public final class SampleSongs {
    private SampleSongs() { }

    public static void generate(File dir) throws IOException {
        dir.mkdirs();
        String[] names = {"Dó", "Ré", "Mi", "Fá"};
        double[] freq = {261.63, 293.66, 329.63, 349.23};
        StringBuilder tsv = new StringBuilder("# arquivo<TAB>resposta1|resposta2\n");
        for (int i = 0; i < names.length; i++) {
            write(new File(dir, String.format("%02d.wav", i + 1)), freq[i], 4);
            tsv.append(String.format("%02d.wav\t%s|nota %s\n", i + 1, names[i], names[i]));
        }
        Files.write(new File(dir, "songs.tsv").toPath(), tsv.toString().getBytes(StandardCharsets.UTF_8));
    }

    private static void write(File f, double hz, int secs) throws IOException {
        float rate = 22050f;
        byte[] buf = new byte[(int) (rate * secs) * 2];
        for (int i = 0; i < buf.length / 2; i++) {
            double env = Math.min(1.0, Math.min(i / 2000.0, (buf.length / 2 - i) / 2000.0));
            short v = (short) (Math.sin(2 * Math.PI * hz * i / rate) * 9000 * env);
            buf[2 * i] = (byte) (v & 0xff);
            buf[2 * i + 1] = (byte) ((v >> 8) & 0xff);
        }
        AudioFormat fmt = new AudioFormat(rate, 16, 1, true, false);
        try (AudioInputStream ais = new AudioInputStream(new ByteArrayInputStream(buf), fmt, buf.length / 2)) {
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, f);
        }
    }
}
